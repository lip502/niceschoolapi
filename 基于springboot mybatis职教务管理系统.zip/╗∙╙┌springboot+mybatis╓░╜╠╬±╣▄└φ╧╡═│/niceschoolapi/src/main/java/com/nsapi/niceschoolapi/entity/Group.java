package com.nsapi.niceschoolapi.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.nsapi.niceschoolapi.common.base.TreeEntity;

@TableName("sys_group")
public class Group extends TreeEntity<Group> {
    private static final long serialVersionUID = 1L;
}
