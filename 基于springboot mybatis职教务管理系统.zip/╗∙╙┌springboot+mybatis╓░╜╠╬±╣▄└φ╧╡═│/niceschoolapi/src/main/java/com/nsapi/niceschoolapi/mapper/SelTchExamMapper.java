package com.nsapi.niceschoolapi.mapper;

import com.nsapi.niceschoolapi.entity.SelTchExamVO;

import java.util.List;
import java.util.Map;

public interface SelTchExamMapper {
    List<Map> selTchExam(SelTchExamVO selTchExamVO);
}
